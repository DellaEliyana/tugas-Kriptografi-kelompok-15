<?php
class PlayfairCipher {
    private $key;
    private $matrix = [];

    public function __construct($key) {
        $this->key = strtoupper($key);
        $this->createMatrix();
    }

    // Membuat matriks Playfair dari kunci
    private function createMatrix() {
        $alphabet = 'ABCDEFGHIKLMNOPQRSTUVWXYZ'; // 'J' dihilangkan atau digabungkan dengan 'I'
        $keyString = '';

        // Menghilangkan duplikat karakter dari kunci dan menambahkannya ke string
        for ($i = 0; $i < strlen($this->key); $i++) {
            if (strpos($keyString, $this->key[$i]) === false && $this->key[$i] !== 'J') {
                $keyString .= $this->key[$i];
            }
        }

        // Menambahkan sisa alfabet
        for ($i = 0; $i < strlen($alphabet); $i++) {
            if (strpos($keyString, $alphabet[$i]) === false) {
                $keyString .= $alphabet[$i];
            }
        }

        // Membuat matriks 5x5
        for ($i = 0; $i < 5; $i++) {
            $this->matrix[$i] = str_split(substr($keyString, $i * 5, 5));
        }
    }

    // Fungsi untuk mengenkripsi teks
    public function encrypt($text) {
        $text = strtoupper($text);
        $text = preg_replace('/[^A-Z]/', '', $text);
        $text = str_replace('J', 'I', $text); // Ganti 'J' dengan 'I'
        
        // Membuat pasangan huruf
        $pairs = [];
        for ($i = 0; $i < strlen($text); $i += 2) {
            $firstChar = $text[$i];
            $secondChar = ($i + 1 < strlen($text)) ? $text[$i + 1] : 'X'; // Tambahkan 'X' jika huruf ganjil

            if ($firstChar === $secondChar) {
                $secondChar = 'X'; // Jika huruf sama, ganti dengan 'X'
                $i--;
            }

            $pairs[] = $firstChar . $secondChar;
        }

        $cipherText = '';
        foreach ($pairs as $pair) {
            $cipherText .= $this->encryptPair($pair);
        }

        return $cipherText;
    }

    // Fungsi untuk mengenkripsi pasangan huruf
    private function encryptPair($pair) {
        $pos1 = $this->findPosition($pair[0]);
        $pos2 = $this->findPosition($pair[1]);

        if ($pos1[0] === $pos2[0]) {
            // Same row: shift right
            return $this->matrix[$pos1[0]][($pos1[1] + 1) % 5] . $this->matrix[$pos2[0]][($pos2[1] + 1) % 5];
        } elseif ($pos1[1] === $pos2[1]) {
            // Same column: shift down
            return $this->matrix[($pos1[0] + 1) % 5][$pos1[1]] . $this->matrix[($pos2[0] + 1) % 5][$pos2[1]];
        } else {
            // Rectangle: swap columns
            return $this->matrix[$pos1[0]][$pos2[1]] . $this->matrix[$pos2[0]][$pos1[1]];
        }
    }

    // Fungsi untuk menemukan posisi huruf di matriks
    private function findPosition($char) {
        for ($i = 0; $i < 5; $i++) {
            for ($j = 0; $j < 5; $j++) {
                if ($this->matrix[$i][$j] === $char) {
                    return [$i, $j];
                }
            }
        }
        return [-1, -1]; // Jika tidak ditemukan
    }

    // Fungsi untuk mendekripsi teks
    public function decrypt($text) {
        // Implementasi dekripsi
        $text = strtoupper($text);
        $text = preg_replace('/[^A-Z]/', '', $text);
        $pairs = [];
        
        for ($i = 0; $i < strlen($text); $i += 2) {
            $firstChar = $text[$i];
            $secondChar = ($i + 1 < strlen($text)) ? $text[$i + 1] : 'X'; // Tambahkan 'X' jika huruf ganjil
            $pairs[] = $firstChar . $secondChar;
        }

        $plainText = '';
        foreach ($pairs as $pair) {
            $plainText .= $this->decryptPair($pair);
        }

        return $plainText;
    }

    // Fungsi untuk mendekripsi pasangan huruf
    private function decryptPair($pair) {
        $pos1 = $this->findPosition($pair[0]);
        $pos2 = $this->findPosition($pair[1]);

        if ($pos1[0] === $pos2[0]) {
            // Same row: shift left
            return $this->matrix[$pos1[0]][($pos1[1] + 4) % 5] . $this->matrix[$pos2[0]][($pos2[1] + 4) % 5];
        } elseif ($pos1[1] === $pos2[1]) {
            // Same column: shift up
            return $this->matrix[($pos1[0] + 4) % 5][$pos1[1]] . $this->matrix[($pos2[0] + 4) % 5][$pos2[1]];
        } else {
            // Rectangle: swap columns
            return $this->matrix[$pos1[0]][$pos2[1]] . $this->matrix[$pos2[0]][$pos1[1]];
        }
    }
}
