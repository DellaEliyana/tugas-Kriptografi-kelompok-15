<?php
class VigenereCipher {
    public function encrypt($text, $key) {
        $result = '';
        $text = strtoupper($text);
        $key = strtoupper($key);
        $keyLength = strlen($key);
        
        for ($i = 0, $j = 0; $i < strlen($text); $i++) {
            $currentChar = $text[$i];
            if (ctype_alpha($currentChar)) {
                $result .= chr((ord($currentChar) + ord($key[$j % $keyLength]) - 2 * ord('A')) % 26 + ord('A'));
                $j++;
            } else {
                $result .= $currentChar; // Non-alphabetic characters are added unchanged
            }
        }
        return $result;
    }

    public function decrypt($text, $key) {
        $result = '';
        $text = strtoupper($text);
        $key = strtoupper($key);
        $keyLength = strlen($key);
        
        for ($i = 0, $j = 0; $i < strlen($text); $i++) {
            $currentChar = $text[$i];
            if (ctype_alpha($currentChar)) {
                $result .= chr((ord($currentChar) - ord($key[$j % $keyLength]) + 26) % 26 + ord('A'));
                $j++;
            } else {
                $result .= $currentChar; // Non-alphabetic characters are added unchanged
            }
        }
        return $result;
    }
}
