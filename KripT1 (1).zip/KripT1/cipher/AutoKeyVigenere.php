<?php
class AutoKeyVigenere {
    private $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    // Fungsi untuk mengenkripsi teks menggunakan Auto-Key Vigenere Cipher
    public function encrypt($text, $key) {
        $text = strtoupper($this->sanitizeText($text));
        $key = strtoupper($key);
        
        // Memperpanjang kunci dengan plainteks setelah kunci asli habis
        $extendedKey = $this->extendKey($text, $key);
        
        $cipherText = '';
        for ($i = 0; $i < strlen($text); $i++) {
            $cipherText .= $this->shiftLetter($text[$i], $extendedKey[$i]);
        }

        return $cipherText;
    }

    // Fungsi untuk mendekripsi teks menggunakan Auto-Key Vigenere Cipher
    public function decrypt($cipherText, $key) {
        $cipherText = strtoupper($this->sanitizeText($cipherText));
        $key = strtoupper($key);
        
        $plainText = '';
        $keyLength = strlen($key);

        for ($i = 0; $i < strlen($cipherText); $i++) {
            // Menggunakan kunci yang diperpanjang
            $currentKey = ($i < $keyLength) ? $key[$i] : $plainText[$i - $keyLength];
            $decryptedChar = $this->unshiftLetter($cipherText[$i], $currentKey);
            $plainText .= $decryptedChar;

            // Memperpanjang kunci dengan menambahkan karakter yang didekripsi
            if ($i >= $keyLength) {
                // Menambahkan karakter yang didekripsi untuk memperpanjang kunci
                $key .= $decryptedChar; 
            }
        }

        return $plainText;
    }

    // Fungsi untuk memperpanjang kunci dengan menambahkan plainteks
    private function extendKey($text, $key) {
        return $key . substr($text, strlen($key)); // Memperpanjang kunci
    }

    // Fungsi untuk membersihkan teks dari karakter selain huruf alfabet
    private function sanitizeText($text) {
        return preg_replace('/[^A-Z]/', '', strtoupper($text));
    }

    // Fungsi untuk mengenkripsi satu huruf
    private function shiftLetter($letter, $keyLetter) {
        $letterPos = strpos($this->alphabet, $letter);
        $keyPos = strpos($this->alphabet, $keyLetter);
        return $this->alphabet[($letterPos + $keyPos) % 26];
    }

    // Fungsi untuk mendekripsi satu huruf
    private function unshiftLetter($letter, $keyLetter) {
        $letterPos = strpos($this->alphabet, $letter);
        $keyPos = strpos($this->alphabet, $keyLetter);
        return $this->alphabet[($letterPos - $keyPos + 26) % 26];
    }
}
