<?php
class SuperEncryption {
    private $vigenereKey;
    private $transpositionKey;

    // Konstruktor untuk menerima kunci Vigenere dan kunci Transposisi
    public function __construct($vigenereKey, $transpositionKey) {
        $this->vigenereKey = $vigenereKey;
        $this->transpositionKey = $transpositionKey;
    }

    // Fungsi untuk mengenkripsi teks menggunakan kombinasi Vigenere dan Transposisi Kolom
    public function encrypt($text) {
        // Langkah 1: Enkripsi dengan Vigenere Cipher
        $vigenereEncrypted = $this->vigenereEncrypt($text, $this->vigenereKey);
        
        // Langkah 2: Enkripsi dengan Transposisi Kolom
        $superEncrypted = $this->columnarTranspositionEncrypt($vigenereEncrypted, $this->transpositionKey);
        
        return $superEncrypted;
    }

    // Fungsi untuk mendekripsi teks yang dienkripsi dengan Super Encryption
    public function decrypt($cipherText) {
        // Langkah 1: Dekripsi dengan Transposisi Kolom
        $transpositionDecrypted = $this->columnarTranspositionDecrypt($cipherText, $this->transpositionKey);

        // Langkah 2: Dekripsi dengan Vigenere Cipher
        $superDecrypted = $this->vigenereDecrypt($transpositionDecrypted, $this->vigenereKey);

        return $superDecrypted;
    }

    // Fungsi untuk mengenkripsi teks menggunakan Vigenere Cipher
    private function vigenereEncrypt($text, $key) {
        $text = strtoupper($this->sanitizeText($text));
        $key = strtoupper($this->sanitizeText($key));

        $keyLength = strlen($key);
        $textLength = strlen($text);
        $cipherText = '';

        for ($i = 0; $i < $textLength; $i++) {
            $keyChar = $key[$i % $keyLength];
            $textChar = $text[$i];

            $encryptedChar = chr(((ord($textChar) - ord('A') + ord($keyChar) - ord('A')) % 26) + ord('A'));
            $cipherText .= $encryptedChar;
        }

        return $cipherText;
    }

    // Fungsi untuk mendekripsi teks menggunakan Vigenere Cipher
    private function vigenereDecrypt($cipherText, $key) {
        $cipherText = strtoupper($this->sanitizeText($cipherText));
        $key = strtoupper($this->sanitizeText($key));

        $keyLength = strlen($key);
        $textLength = strlen($cipherText);
        $plainText = '';

        for ($i = 0; $i < $textLength; $i++) {
            $keyChar = $key[$i % $keyLength];
            $cipherChar = $cipherText[$i];

            $decryptedChar = chr(((ord($cipherChar) - ord($keyChar) + 26) % 26) + ord('A'));
            $plainText .= $decryptedChar;
        }

        return $plainText;
    }

    // Fungsi untuk mengenkripsi teks menggunakan Columnar Transposition Cipher
    private function columnarTranspositionEncrypt($text, $key) {
        $keyLength = strlen($key);
        $columns = array_fill(0, $keyLength, '');

        // Memasukkan karakter ke dalam kolom sesuai dengan panjang kunci
        for ($i = 0; $i < strlen($text); $i++) {
            $columns[$i % $keyLength] .= $text[$i];
        }

        // Mengurutkan kolom berdasarkan urutan alfabet kunci
        $sortedKey = str_split($key);
        sort($sortedKey);

        $cipherText = '';
        foreach ($sortedKey as $char) {
            $index = strpos($key, $char);
            $cipherText .= $columns[$index];
        }

        return $cipherText;
    }

    // Fungsi untuk mendekripsi teks yang dienkripsi dengan Columnar Transposition Cipher
    private function columnarTranspositionDecrypt($cipherText, $key) {
        $keyLength = strlen($key);
        $numRows = ceil(strlen($cipherText) / $keyLength);
        $columns = array_fill(0, $keyLength, '');

        // Mengurutkan kolom berdasarkan urutan alfabet kunci
        $sortedKey = str_split($key);
        sort($sortedKey);

        // Hitung jumlah karakter per kolom
        $columnLengths = array_fill(0, $keyLength, $numRows);
        $shortColumns = $keyLength * $numRows - strlen($cipherText);
        for ($i = 0; $i < $shortColumns; $i++) {
            $columnLengths[$i]--;
        }

        // Membaca ciphertext berdasarkan urutan kolom
        $currentIndex = 0;
        foreach ($sortedKey as $char) {
            $index = strpos($key, $char);
            $columns[$index] = substr($cipherText, $currentIndex, $columnLengths[$index]);
            $currentIndex += $columnLengths[$index];
        }

        // Mengembalikan teks asli dari kolom yang terurut
        $plainText = '';
        for ($i = 0; $i < $numRows; $i++) {
            for ($j = 0; $j < $keyLength; $j++) {
                if (isset($columns[$j][$i])) {
                    $plainText .= $columns[$j][$i];
                }
            }
        }

        return $plainText;
    }

    // Fungsi untuk membersihkan teks dari karakter selain huruf alfabet
    private function sanitizeText($text) {
        return preg_replace('/[^A-Za-z]/', '', strtoupper($text));
    }
}

?>