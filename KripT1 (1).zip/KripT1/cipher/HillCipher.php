<?php
class HillCipher {
    private $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    // Fungsi untuk mengenkripsi teks menggunakan Hill Cipher
    public function encrypt($text, $keyMatrix) {
        $text = strtoupper($this->sanitizeText($text));
        $matrixSize = sqrt(count($keyMatrix));

        if ($matrixSize != floor($matrixSize)) {
            throw new Exception("Invalid key matrix size. It must be a square matrix.");
        }

        // Memastikan bahwa panjang plainteks merupakan kelipatan ukuran matriks
        $text = $this->padText($text, $matrixSize);

        $cipherText = '';
        for ($i = 0; $i < strlen($text); $i += $matrixSize) {
            $block = substr($text, $i, $matrixSize);
            $cipherText .= $this->encryptBlock($block, $keyMatrix, $matrixSize);
        }

        return $cipherText;
    }

    // Fungsi untuk mendekripsi teks menggunakan Hill Cipher
    public function decrypt($cipherText, $keyMatrix) {
        $cipherText = strtoupper($this->sanitizeText($cipherText));
        $matrixSize = sqrt(count($keyMatrix));

        if ($matrixSize != floor($matrixSize)) {
            throw new Exception("Invalid key matrix size. It must be a square matrix.");
        }

        // Hitung invers matriks kunci
        $inverseKeyMatrix = $this->matrixInverse($keyMatrix, 26);

        $plainText = '';
        for ($i = 0; $i < strlen($cipherText); $i += $matrixSize) {
            $block = substr($cipherText, $i, $matrixSize);
            $plainText .= $this->encryptBlock($block, $inverseKeyMatrix, $matrixSize);
        }

        return $plainText;
    }

    // Fungsi untuk membersihkan teks dari karakter selain huruf alfabet
    private function sanitizeText($text) {
        return preg_replace('/[^A-Z]/', '', strtoupper($text));
    }

    // Fungsi untuk menambahkan padding jika panjang teks tidak sesuai dengan ukuran blok
    private function padText($text, $matrixSize) {
        while (strlen($text) % $matrixSize != 0) {
            $text .= 'X';  // Padding dengan huruf 'X'
        }
        return $text;
    }

    // Fungsi untuk mengenkripsi satu blok teks
    private function encryptBlock($block, $keyMatrix, $matrixSize) {
        $vector = $this->textToVector($block);
        $resultVector = [];

        for ($i = 0; $i < $matrixSize; $i++) {
            $resultVector[$i] = 0;
            for ($j = 0; $j < $matrixSize; $j++) {
                $resultVector[$i] += $keyMatrix[$i][$j] * $vector[$j];
            }
            $resultVector[$i] = $resultVector[$i] % 26;
        }

        return $this->vectorToText($resultVector);
    }

    // Fungsi untuk mengubah teks menjadi vektor angka
    private function textToVector($text) {
        $vector = [];
        for ($i = 0; $i < strlen($text); $i++) {
            $vector[] = strpos($this->alphabet, $text[$i]);
        }
        return $vector;
    }

    // Fungsi untuk mengubah vektor angka menjadi teks
    private function vectorToText($vector) {
        $text = '';
        foreach ($vector as $num) {
            $text .= $this->alphabet[$num];
        }
        return $text;
    }

    // Fungsi untuk menghitung invers matriks dengan modulus tertentu (misalnya 26)
    private function matrixInverse($matrix, $modulus) {
        // Asumsi: Matriks adalah matriks 2x2 atau 3x3 yang dapat di-invers
        $det = $this->matrixDeterminant($matrix);
        $detInv = $this->modInverse($det, $modulus);
        if ($detInv === null) {
            throw new Exception("Matrix determinant has no modular inverse. Decryption not possible.");
        }

        $matrixSize = sqrt(count($matrix));
        $inverseMatrix = [];

        if ($matrixSize == 2) {
            // Matriks 2x2
            $inverseMatrix[0][0] = $matrix[1][1] * $detInv % $modulus;
            $inverseMatrix[0][1] = -$matrix[0][1] * $detInv % $modulus;
            $inverseMatrix[1][0] = -$matrix[1][0] * $detInv % $modulus;
            $inverseMatrix[1][1] = $matrix[0][0] * $detInv % $modulus;
        } else if ($matrixSize == 3) {
            // Matriks 3x3 (atau perlu implementasi lebih lanjut)
            throw new Exception("3x3 matrix inverse is not yet implemented.");
        }

        // Pastikan nilai elemen matriks tetap positif setelah operasi modulus
        for ($i = 0; $i < $matrixSize; $i++) {
            for ($j = 0; $j < $matrixSize; $j++) {
                $inverseMatrix[$i][$j] = ($inverseMatrix[$i][$j] + $modulus) % $modulus;
            }
        }

        return $inverseMatrix;
    }

    // Fungsi untuk menghitung determinan matriks 2x2
    private function matrixDeterminant($matrix) {
        return ($matrix[0][0] * $matrix[1][1] - $matrix[0][1] * $matrix[1][0]) % 26;
    }

    // Fungsi untuk menghitung invers dari determinan dengan modulus tertentu
    private function modInverse($a, $m) {
        $a = $a % $m;
        for ($x = 1; $x < $m; $x++) {
            if (($a * $x) % $m == 1) {
                return $x;
            }
        }
        return null;
    }
}